package com.pkg.main;
/*
 * Author Mrunalini
 */

public class TrafficSignal {

	int EastWeaverRd;
	int WestWeaverRd;
	int NorthSnellRd;
	int SouthSnellRd;	
	int seconds;
	int totalSeconds;
	
	public static void main(String[] args) {
		
		TrafficSignal trafficSig = new TrafficSignal(0,0,0,0,20);
		trafficSig.CarsAtSignal();

	}
	
	// Constructor 
	public TrafficSignal(int NorthSnellRdStart, int SouthSnellRdStart, int WeaverEastStart, int WestWeaverRdStart, int totalSec)	{
		
		NorthSnellRd = NorthSnellRdStart;
		SouthSnellRd = SouthSnellRdStart;
		EastWeaverRd = WeaverEastStart;
		WestWeaverRd = WestWeaverRdStart;
		totalSeconds = totalSec;
	}
		
	private void CarsAtSignal()	{
		
		int count;
		
		System.out.println(this.seconds+": N = " + this.NorthSnellRd+"; S = " + this.SouthSnellRd + "; E = " + this.EastWeaverRd + "; W = " + this.WestWeaverRd);
		
		for (this.seconds = 1; this.seconds <= totalSeconds; this.seconds++)
		{
			count = seconds % 8;
			switch(count)
			{
					
			case 1:
				if(seconds == 1){ // if condition is only for first 3 seconds as cars will not be waiting on Snell Rd
					this.NorthSnellRd = 0;
				    this.SouthSnellRd = 0;
				    this.EastWeaverRd += 1;
				    this.WestWeaverRd += 1;
				    break;
				}else{
					this.NorthSnellRd += 1;
				    this.SouthSnellRd += 1;
				    this.EastWeaverRd += 1;
				    this.WestWeaverRd += 1;
				    break;
				}
			case 0:	
			case 5: this.NorthSnellRd += 1;
				    this.SouthSnellRd += 1;
				    this.EastWeaverRd += 1;
				    this.WestWeaverRd += 1;
				    break;
			case 2: 
				if(seconds == 2){
					this.NorthSnellRd = 0;
				    this.SouthSnellRd = 0;
				    this.EastWeaverRd += 1;
				    this.WestWeaverRd += 1;
				    break;
				}else{
				    this.EastWeaverRd += 1;
				    this.WestWeaverRd += 1;
				    break;
				}
			case 3:
				if(seconds == 3){
					this.NorthSnellRd = 0;
				    this.SouthSnellRd = 0;
				    this.EastWeaverRd += 1;
				    this.WestWeaverRd += 1;
				    break;
				}else{
					this.EastWeaverRd += 1;
    	    		this.WestWeaverRd += 1;
    	    		break;
				}
			case 4: 
					this.NorthSnellRd += 1;
					this.SouthSnellRd += 1;
					this.EastWeaverRd += 1;
    	    		this.WestWeaverRd += 1;
    	    		break;
			case 6: 
			case 7:	this.NorthSnellRd += 1;
    				this.SouthSnellRd += 1;
    				break;				    
			}
			
			System.out.println(this.seconds+": N = " + this.NorthSnellRd+"; S = " + this.SouthSnellRd + "; E = " + this.EastWeaverRd + "; W = " + this.WestWeaverRd);			
		}
	}
	

}
